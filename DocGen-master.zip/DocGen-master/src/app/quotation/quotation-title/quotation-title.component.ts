import { Component, OnInit,ViewEncapsulation,ElementRef,ViewChild, VERSION } from '@angular/core';
import { QuotationService } from "../../service/quotation.service";
import { DocGeneratorService } from "../../service/doc-generator.service";
import { QuotationTitle } from "../../model/quotationTitle";
import {  DocumentEditorComponent } from '@syncfusion/ej2-angular-documenteditor';
import { Packer } from "docx";
import * as fs from 'file-saver';
import { AlignmentType, Document, HeadingLevel, Paragraph, TabStopPosition, TabStopType, TextRun, BorderStyle, Table, TableCell , TableRow} from "docx";
//import { DocumentCreator } from "../doc-generator";
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'app-quotation-title',
  templateUrl: './quotation-title.component.html',  
  styleUrls: ['./quotation-title.component.css'], 
})
export class QuotationTitleComponent implements OnInit {

  @ViewChild('document_editor')
  public documentEditor: DocumentEditorComponent;  
  @ViewChild('document_editor1') 
  public myDiv: any;  
  public quotationModel : QuotationTitle;
  headerTitle?: any;
  items: string[] = [ "Avv", "Bvv"];
  headerTag?: ElementRef;
  subTitle: string;
  headerContecnt: string;
  paraContent: string;
  name = 'Angular ' +  VERSION.major;  
  fileUrl: any;
   model: any = {
    alertMsg: "<p>Sample content</p>"
  };
  htmlelent: HTMLElement;
  eleOuterDiv: any;
  css: any= (
    '<style>' +
    '@page WordSection1{size: 841.95pt 595.35pt;mso-page-orientation: landscape;}' +
    'div.WordSection1 {page: WordSection1s;}' +
    'table{border-collapse:collapse;}td{border:1px gray solid;width:5em;padding:2px;}'+

    '</style>'
  );

  isEditHeading: boolean = false;

 constructor(private quotationService: QuotationService, private DocGeneratorService: DocGeneratorService,private sanitizer: DomSanitizer) {
  
 }
 public getJSON() {
   this.quotationService.getJSON().subscribe(data => {
    console.log(data);
    
    if(data != null)
    {
      this.quotationModel = data;  
      console.log("quotation model ",this.quotationModel);
    this.quotationModel.templates.forEach(element => {    

      this.eleOuterDiv = document.createElement("div");     
      //this.eleOuterDiv.className ="text-align"  
      this.eleOuterDiv.setAttribute("style", "text-align: center;");  
      element.sections.forEach(s => {

        if(s.sectionType == "Heading")
        {                 
          var element = this.createElement(s); 
          element.setAttribute("style", " margin-top: 5em;"); 

          var editBtn = document.createElement('span'); 
          // editBtn.setAttribute("style", " background-color:transparent;margin-top: 5em;");     
          editBtn.className = "edit-btn";
          //editBtn.setAttribute('ng-click', 'editHeading()');  
          editBtn.onclick = this.editHeading;
          var editele =  document.createElement('i');     
          editele.className = "bi bi-pencil-square";
         

          editBtn.appendChild(editele);          
          this.eleOuterDiv.appendChild(element);
          this.eleOuterDiv.appendChild(editBtn);

          this.headerTitle = s.sectionContent;
        }
       
        if(s.sectionType == "Subheading")
        {
          var element = this.createElement(s);             
          this.eleOuterDiv.appendChild(element);
          this.subTitle = s.sectionContent;
        }
       
        if(s.sectionType == "PARA")
        {
          var element = this.createElement(s);
          element.setAttribute("style", " margin-left: 10%;margin-right: 10%;margin-top: 5em;text-align: left;padding: 10px;border: 1px solid;"); 
          this.eleOuterDiv.appendChild(element);
          this.paraContent = s.sectionContent;
        }     
        
        const app = document.getElementById("container2");
        app?.appendChild(this.eleOuterDiv);

        
        

        //this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(window.URL.createObjectURL(blob));
      });
    });
    
    }
   });
 }

 editHeading()
 {
   if(this.isEditHeading)
   this.isEditHeading= false;
   else
   this.isEditHeading= true;
   console.log("edit heading called");
 }

 exportWord()
 {
  const app = document.getElementById("container2");
  const blob = new Blob(['\ufeff', this.css + app?.innerHTML], { type: 'application/msword' });
  var url = URL.createObjectURL(blob);
  var link = document.createElement('A');
  link.setAttribute("href", url);
  // Set default file name. 
  // Word will append file extension - do not add an extension here.
  link.setAttribute("download", 'Document');  
  document.body.appendChild(link);
  if (navigator.msSaveOrOpenBlob ) navigator.msSaveOrOpenBlob( blob, 'Document.doc'); // IE10-11
      else link.click();  // other browsers
  document.body.removeChild(link);
 }
  
 createElement(section: any) : HTMLElement
 {  
  var element = document.createElement(section.sectionMetadata?.headerStyle? section.sectionMetadata?.headerStyle : "H1");       
  element.textContent = section.sectionContent;
  element.style.fontFamily = section.sectionMetadata?.headerFont? section.sectionMetadata?.headerFont : "Aerial";
  return element;
 }  

 ngOnInit() {
  
   this.getJSON();

   const data1 = this.myDiv;
   console.log('data1',this.myDiv);
   const data = 'some text';
  

 } 

 public saveAsDocx() :void {
   this.documentEditor.save('sample','Docx');
 }

 public download(): void {
  //const document = new Document();
  //const documentCreator = new DocumentCreator();
  // const doc = this.DocGeneratorService.create();

  // Packer.toBlob(doc).then(buffer => {
  //   console.log(buffer);
  //   fs.saveAs(buffer, "example.docx");
  //   console.log("Document created successfully");
  // });  

//   var docDOM = document.getElementById('example');

// var docObject = docx.export(docDOM, // required DOM Object
// {
// creator: "Creator", // optional String
// lastModifiedBy: "Last person to modify", // optional String
// created: new Date(), // optional Date Object
// modified: new Date() // optional Date Object
// });

// var link = document.createElement('a');
// link.appendChild(document.createTextNode("Download Link Text"));
// link.title = "Download Title";
// link.download = "FilenameHere.docx";
// link.href = docObject.href();

// document.getElementById("example").appendChild(link);

}

} 