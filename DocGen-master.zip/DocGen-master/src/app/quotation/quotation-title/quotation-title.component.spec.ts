import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotationTitleComponent } from './quotation-title.component';

describe('QuotationTitleComponent', () => {
  let component: QuotationTitleComponent;
  let fixture: ComponentFixture<QuotationTitleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuotationTitleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuotationTitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
