export enum Style{
BOLD = 1,
ITALIC = 2
}
