import { Metadata } from "../model/metadata";

export class Section{
    sectionID? : string;
    isComplex? : string;
    sectionTitle?: string;
    titleMetadata?: Metadata;
    sectionType? : string;
    sectionContent : string;
    sectionMetadata? : Metadata;   
}