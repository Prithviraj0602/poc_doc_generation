import { Section } from "../model/section";
export class Template{
    templateID : string;
    sections : Section[];
}