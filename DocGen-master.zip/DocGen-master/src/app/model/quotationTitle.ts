import { Template } from "../model/template";
export class QuotationTitle
{   
    globalDocumentId: string;
    templates: Template[];
}